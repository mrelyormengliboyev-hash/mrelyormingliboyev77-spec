# EduPrime — Premium Education Center Website Template

Thank you for choosing EduPrime. This is a static HTML/CSS/JavaScript website
template built for education centers, language schools, tutoring businesses
and similar organizations. No build tools, backend, or database are required.

**Status: Complete.** This package contains all five pages: **Home,
Courses, Teachers, About and Contact** — fully linked together, sharing
one consistent design system, navigation and footer.

## Quick Start

1. Unzip the project folder anywhere on your computer.
2. Double-click `index.html` to open it in your browser. That's it — no
   installation, no server, no build step.
3. To make it live, upload the entire folder to any static web host
   (e.g. your hosting provider's file manager, Netlify, GitHub Pages).

## What's Included

```
eduprime-template/
├── index.html                  # Home page
├── courses.html                 # Course catalog with category filtering
├── teachers.html                 # Teacher directory with category filtering
├── about.html                     # About / mission / philosophy / stats
├── contact.html                    # Contact info, validated form, map placeholder
├── assets/
│   ├── css/
│   │   ├── tokens.css         # Colors, fonts, spacing — edit this first
│   │   ├── base.css           # Resets & base element styles
│   │   ├── layout.css         # Containers, grids, section spacing
│   │   ├── components.css     # Buttons, cards, nav, footer, forms, filters, etc.
│   │   └── pages.css          # Hero, stats, final-CTA and other reused section styles
│   ├── js/
│   │   ├── navigation.js      # Mobile menu, sticky header, active link
│   │   ├── components.js      # FAQ accordion, stat counters, back-to-top, filters, form validation
│   │   └── main.js            # Page entry point — wires everything above together
│   ├── icons/
│   │   └── favicon.svg
│   └── images/                # Empty by design — see CUSTOMIZATION-GUIDE.md
├── README.md
├── CUSTOMIZATION-GUIDE.md
└── LICENSE.txt
```

## What's NOT Included

To keep this template lightweight, host-anywhere and dependency-free,
it deliberately does **not** include:

- A backend, server, or database of any kind
- User accounts, authentication, or an admin panel
- A payment or checkout system
- A CMS — all content is edited directly in the HTML files
- A real email-sending service for the contact form (it validates
  fields and shows a demo success state only — see below)
- Any build tools, package manager, or compile step
- Stock photography or third-party image/icon packs (every visual is
  original inline SVG or CSS)
- Real Privacy Policy / Terms of Service text (the footer links are
  placeholders — see `CUSTOMIZATION-GUIDE.md`, section 15)

## How To Change Your Brand Colors and Fonts

Open `assets/css/tokens.css`. Every color, font, spacing value, corner
radius and shadow used anywhere on the site is defined once at the top of
that file as a CSS variable. Change a value there and the whole site updates
automatically — see `CUSTOMIZATION-GUIDE.md` for a full walkthrough.

## Editing Text Content

Open `index.html` in any text editor. Every editable section is marked with
a comment like:

```html
<!-- EDIT: Course Information -->
```

You do not need to know HTML or JavaScript to change text — find the
comment, edit the plain text near it, and save the file.

## Browser Support

Built and tested against current versions of Chrome, Firefox, Safari and
Edge. Uses modern, broadly-supported CSS (Grid, Flexbox, custom properties,
`clamp()`) and vanilla JavaScript — no external libraries or frameworks.

## Support

This template does not include a backend, database, authentication or
payment system by design, so it can be hosted anywhere for free or very
low cost. The contact form on the Contact page performs front-end
validation only and shows a demo success message that explicitly tells
the visitor nothing was sent — **it does not send messages anywhere
until you connect it to a real email or form-backend service.** Full
step-by-step instructions for that, plus how to swap in a real map, are
in `CUSTOMIZATION-GUIDE.md`.

All demo content (names, testimonials, statistics, contact details) is
fictional and must be replaced before publishing — see
`CUSTOMIZATION-GUIDE.md` for exactly where to edit each piece. See
`LICENSE.txt` for template usage terms.
