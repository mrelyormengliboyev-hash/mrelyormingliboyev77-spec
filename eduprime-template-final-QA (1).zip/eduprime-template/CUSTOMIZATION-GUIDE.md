# EduPrime — Customization Guide (Complete: All 5 Pages)

No coding experience required for the tasks below. Open files in any plain
text editor (Notepad, TextEdit, VS Code, etc.) — never Microsoft Word, which
adds hidden formatting that can break the page.

---

## 1. Change Your Academy Name and Logo

The logo is text-based by default, so there's no image file to replace.

Open `index.html` and find (it appears twice — header and footer):

```html
<a href="index.html" class="logo" aria-label="EduPrime Academy — home">
  <span class="logo__mark">Edu</span><span>Prime</span>
</a>
```

Replace `Edu` and `Prime` with your own name, e.g. for "Brightpath Academy":

```html
<span class="logo__mark">Bright</span><span>path</span>
```

**This block appears in the same form at the top of every page**
(`index.html`, `courses.html`, `teachers.html`, `about.html`,
`contact.html`) — update it in all five files, plus every appearance of
"EduPrime Academy" in the page copy (hero text, footer, FAQ answers).

If you'd rather use an image logo, replace the `<a class="logo">` block with:

```html
<a href="index.html" class="logo">
  <img src="assets/images/your-logo.png" alt="Your Academy Name" height="36">
</a>
```

Each page also has its own `<title>` and `<meta name="description">` tags
near the top of the file (inside `<head>`) — update those on all five pages
too, since they control what shows up in browser tabs and search results.

## 2. Change Your Brand Colors

Open `assets/css/tokens.css`. Near the top you'll see:

```css
--color-primary:        #0F2A4A;
--color-accent:         #D9A441;
```

Replace these two hex codes with your own brand colors and save — every
button, heading, badge and highlight on the site updates automatically.
Keep `--color-primary` fairly dark and `--color-accent` clearly different
from it, so text stays easy to read.

## 3. Change Fonts

Also in `tokens.css`:

```css
--font-heading: 'Fraunces', ... serif;
--font-body:    'Inter', ... sans-serif;
```

The site works out of the box using safe system font fallbacks. If you'd
like to use the exact Fraunces/Inter webfonts, add self-hosted `.woff2`
files to `assets/fonts/` and link them with an `@font-face` rule at the top
of `tokens.css` — the fallback stack means nothing breaks if you skip this.

## 4. Edit Statistics

Find the statistics section (search for `data-count-to`):

```html
<div class="stat__number"><span data-count-to="1200" data-suffix="+">1,200+</span></div>
<p class="stat__label">Students trained</p>
```

Change three things together: the `data-count-to` number, the visible text
inside the `<span>` (used as a fallback and shown before the animation
runs), and the `data-suffix` (e.g. `+`, `%`, or leave empty).

## 5. Edit or Add a Course Card

Each course lives inside its own `<article class="card card--hover course-card">`
block. Copy an entire block (from `<article...>` to its matching `</article>`)
to add a new course, or delete one to remove it. Inside each block, edit:

- The category badge text (e.g. "IELTS Preparation")
- The course title and description
- The level and duration text
- The price
- The `href` on the "View Details" button (currently links to
  `courses.html`; point it at a specific course anchor if you break the
  catalog into individual course pages)

## 6. Edit or Add a Teacher Card

Same pattern as courses — find `<div class="card teacher-card">` blocks in
the "Meet the team" section and duplicate/edit/delete as needed. The two
letters in `teacher-card__avatar` are simply initials shown in a colored
circle; replace them with the teacher's real initials, or swap the whole
`<div class="teacher-card__avatar">` for an `<img>` tag once you have real
photos.

## 7. Edit Testimonials

Find `<div class="card testimonial-card">` blocks. Edit the quote text,
name, and role. The two-letter avatar works the same way as teacher cards.

## 8. Edit Pricing Plans

Find `<div class="card pricing-card">` blocks (three of them). Edit the
plan name, price, note, and the list of features (each `<li>` is one
feature line). The middle plan has an extra class,
`pricing-card--featured`, and a "Most Popular" badge — move that class to
a different card if you want to highlight a different plan instead.

## 9. Edit Contact Info in the Footer

Find the `footer-contact` list near the bottom of the file and update the
address, phone number (`tel:` link), email (`mailto:` link) and working
hours text. This same information also appears on the Contact page
(see Section 14) — update both places so they stay in sync.

## 10. Edit Social Links

**Footer social icons** (Facebook, Instagram, YouTube, LinkedIn — present
in the footer of all five pages) currently point to each platform's
homepage as a safe, non-broken placeholder, with an `aria-label` that
says "replace with your profile URL" as a reminder. Replace the `href`
on each with your real page/profile:

```html
<a href="https://facebook.com/yourpage" target="_blank" rel="noopener noreferrer" aria-label="EduPrime Academy on Facebook">
<a href="https://instagram.com/yourhandle" target="_blank" rel="noopener noreferrer" aria-label="EduPrime Academy on Instagram">
<a href="https://youtube.com/@yourchannel" target="_blank" rel="noopener noreferrer" aria-label="EduPrime Academy on YouTube">
<a href="https://linkedin.com/company/yourcompany" target="_blank" rel="noopener noreferrer" aria-label="EduPrime Academy on LinkedIn">
```

Once you fill in a real profile URL, you can also drop the "(replace
with your profile URL)" wording from the `aria-label` — it's only there
to flag the placeholder during setup.

**Individual teacher LinkedIn icons** (on the Home page's "Meet the
Team" preview and on the Teachers page) work the same way — each
currently points to `https://www.linkedin.com/` as a placeholder.
Replace with that teacher's real profile URL, or remove the icon
entirely if you don't have one for them.

## 11. Edit Course Categories and Filters (Courses Page)

Each course card is an `<article class="card card--hover course-card" data-category="...">`.
The `data-category` value must exactly match one of the filter button values
above the grid:

```html
<button type="button" class="filter-btn" data-filter="languages" ...>Languages</button>
```

To add a new category (e.g. "Kids"), add a new filter button with a new
`data-filter` value, then set `data-category="kids"` on the course cards
that belong to it. To remove a category, delete its filter button and
either delete the matching course cards or reassign them to a different
category.

## 12. Edit Teacher Categories and Filters (Teachers Page)

Works exactly the same way as course filtering — each
`<div class="card teacher-card" data-category="...">` must match one of
the filter buttons above the teacher grid.

## 13. Edit the About Page

The About page follows the same block-by-block pattern: "Who We Are" and
"Mission & Vision" are plain text blocks, "Why Students Choose Us" and
"Learning Philosophy" use duplicable card blocks (`feature-card` and
`process-step`) just like Home's "Why Choose Us" section, and the
statistics section uses the same `data-count-to` pattern described in
Section 4 of this guide. Keep these numbers consistent with the ones on
the Home page — showing different totals in different places looks
inconsistent to visitors.

## 14. Edit Contact Information (Contact Page)

The Contact page has its own set of info cards near the top — find the
section with four `feature-card` blocks (Address, Phone, Email, Working
Hours) and edit the text, `tel:` link and `mailto:` link directly. This is
in addition to the same information repeated in the footer (Section 9) —
keep both in sync.

## 15. Add Real Privacy Policy / Terms of Service Pages

The **Privacy Policy** and **Terms of Service** links in every page's
footer are intentionally left as placeholders (`href="#"` with a title
tooltip explaining this) — this template does not include legal pages
or legal text, since generic placeholder legal copy could be mistaken
for real policy and isn't a substitute for advice suited to your
business, location and applicable laws.

Before publishing your site:

1. Write or obtain your own Privacy Policy and Terms of Service (a
   lawyer, a legal-document generator, or your organization's existing
   policies).
2. Save them as their own pages (e.g. `privacy.html`, `terms.html`) using
   the same header/footer markup as the other five pages so navigation
   stays consistent.
3. Update the footer links on all five pages from `href="#"` to point at
   those new files, and remove the placeholder `title` attribute.

## 16. Connect the Contact Form to Receive Real Messages

**Important: the contact form does not send anything anywhere by
default.** It only validates the fields in the visitor's browser and shows
a demo "Demo submission received" success panel that explicitly tells the
visitor nothing was sent — this keeps the template free of any
backend, server, or ongoing service dependency, but it means messages
won't reach you until you connect the form yourself. Two common ways to
do that, without writing any backend code:

**Option A — a form-backend service (easiest).** Sign up for a service
like Formspree, Getform, or Web3Forms (any "form as a service" provider
works the same way). They give you a unique endpoint URL. In
`contact.html`, find:

```html
<form class="contact-form" id="contact-form" novalidate>
```

Add `action="https://your-provider-endpoint-url"` and `method="POST"` to
that tag, matching your provider's instructions exactly. You can keep the
existing JavaScript validation as-is — it will still catch empty/invalid
fields before the form submits to your provider.

**Option B — a simple mailto fallback.** For very low volume, you can
change the form's submit button into a plain link:

```html
<a class="btn btn--primary btn--block" href="mailto:hello@youracademy.com">Email Us Instead</a>
```

This opens the visitor's own email app instead of submitting a form — it's
less polished but requires zero setup.

Whichever option you choose, the JavaScript success-panel logic in
`assets/js/components.js` (`initContactForm`) currently fires immediately
after validation passes, without waiting for a real network response. If
you use Option A, check your form-backend provider's documentation for
how to handle their response before showing your own success message
(most simple integrations still work fine as-is for a template-level use
case).

## 17. Replace the Map Placeholder

The "Visit our location" section on the Contact page uses a plain
CSS/SVG placeholder — a dot-grid background with a pin card — so the
template works with zero API keys or third-party scripts. Find:

```html
<div class="map-placeholder" role="img" aria-label="Map showing...">
  ...
</div>
```

To use a real map, delete everything inside `.map-placeholder` (or the
whole element) and paste in an embed code from your provider of choice,
for example a Google Maps "Embed a map" iframe or an OpenStreetMap embed.
Both typically look like:

```html
<iframe src="https://www.google.com/maps/embed?..." width="100%" height="400" style="border:0;" loading="lazy"></iframe>
```

Set `loading="lazy"` (shown above) so the map doesn't slow down the page
for visitors who never scroll to it.

## 18. Replace Placeholder Images with Real Photos

This template ships with **zero photo files** — every visual (icons,
avatars, decorative shapes) is drawn with SVG or CSS, so there's nothing
to accidentally infringe copyright on and nothing that looks broken if you
never add a single photo. When you're ready to add real photos:

- **Teacher headshots:** replace a `<div class="teacher-card__avatar">`
  (the colored circle with initials) with an `<img>` tag, e.g.
  `<img src="assets/images/placeholders/julia-marsh.jpg" alt="Julia Marsh" class="teacher-card__avatar">` — you'll want a small CSS tweak
  (`object-fit: cover; border-radius: 50%;`) if you do this often, or ask
  a developer to add a one-line CSS rule for you.
- **Course/about imagery:** the `course-card__media` icon tiles and the
  `about-preview__visual` block can be swapped for `<img>` tags the same
  way.
- Recommended sizes are noted in `assets/images/placeholders/README.txt`.

## 19. Deploy the Website

This is a fully static site — there is nothing to build or compile.

- **Fastest option:** drag the whole `eduprime-template` folder into a
  static host's dashboard — Netlify and Vercel both support "drop a
  folder" deploys with no configuration.
- **GitHub Pages:** push the folder to a GitHub repository and enable
  Pages in the repository settings, pointing at the root folder.
- **Traditional web hosting:** upload the entire folder via your host's
  file manager or FTP, keeping the folder structure intact (the
  `assets/` folder must stay next to the HTML files).

No environment variables, build step, database, or server-side language
is required in any case.

---
