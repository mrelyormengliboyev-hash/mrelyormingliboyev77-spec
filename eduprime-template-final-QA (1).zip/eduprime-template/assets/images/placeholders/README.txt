Add your own photos here — teacher headshots, course thumbnails, campus
photos, etc. None are required for the site to work: every section that
would normally show a photo currently uses a styled CSS/SVG placeholder
instead, so nothing breaks if this folder stays empty.

Recommended sizes:
- Teacher photos: square, at least 400x400px
- Course thumbnails: 800x500px (16:10 ratio)
- About/hero imagery: at least 900px on the longest side
