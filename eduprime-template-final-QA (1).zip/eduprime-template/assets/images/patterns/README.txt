Optional decorative background images (patterns, textures) can go here.
The current design uses pure CSS/SVG decoration (dot-grid patterns, soft
color shapes) so nothing in this folder is required.
