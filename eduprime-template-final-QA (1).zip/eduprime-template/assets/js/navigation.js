/* ==========================================================================
   EduPrime — Navigation
   Handles: sticky header shadow state, mobile menu open/close (with
   focus handling + Escape key support), and active-link highlighting.
   ========================================================================== */

(function () {
  "use strict";

  const header = document.querySelector(".site-header");
  const navToggle = document.querySelector(".nav-toggle");
  const navMobile = document.querySelector("#nav-mobile");
  const body = document.body;

  /* -----------------------------------------------------------------
     Sticky header elevation on scroll
     ----------------------------------------------------------------- */
  function updateHeaderState() {
    if (!header) return;
    if (window.scrollY > 8) {
      header.classList.add("is-scrolled");
    } else {
      header.classList.remove("is-scrolled");
    }
  }

  let scrollTicking = false;
  window.addEventListener("scroll", function () {
    if (!scrollTicking) {
      window.requestAnimationFrame(function () {
        updateHeaderState();
        scrollTicking = false;
      });
      scrollTicking = true;
    }
  });
  updateHeaderState();

  /* -----------------------------------------------------------------
     Mobile navigation menu
     ----------------------------------------------------------------- */
  if (navToggle && navMobile) {
    const openMenu = function () {
      navMobile.classList.add("is-open");
      navToggle.setAttribute("aria-expanded", "true");
      body.classList.add("nav-open");
      const firstLink = navMobile.querySelector(".nav-mobile__link");
      if (firstLink) firstLink.focus();
    };

    const closeMenu = function (returnFocus) {
      navMobile.classList.remove("is-open");
      navToggle.setAttribute("aria-expanded", "false");
      body.classList.remove("nav-open");
      if (returnFocus) navToggle.focus();
    };

    navToggle.addEventListener("click", function () {
      const isOpen = navToggle.getAttribute("aria-expanded") === "true";
      if (isOpen) {
        closeMenu(false);
      } else {
        openMenu();
      }
    });

    // Close when a nav link is clicked (mobile users tapping through).
    navMobile.querySelectorAll(".nav-mobile__link").forEach(function (link) {
      link.addEventListener("click", function () {
        closeMenu(false);
      });
    });

    // Close on Escape key, return focus to the toggle button.
    document.addEventListener("keydown", function (event) {
      const isOpen = navToggle.getAttribute("aria-expanded") === "true";
      if (event.key === "Escape" && isOpen) {
        closeMenu(true);
      }
    });

    // Close automatically if the viewport grows into the desktop layout.
    window.addEventListener("resize", function () {
      if (window.innerWidth >= 992) {
        closeMenu(false);
      }
    });
  }

  /* -----------------------------------------------------------------
     Active navigation link — matches the current page URL.
     ----------------------------------------------------------------- */
  function setActiveNavLink() {
    const currentPath = window.location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll(".nav-primary__link, .nav-mobile__link").forEach(function (link) {
      const linkPath = link.getAttribute("href");
      if (linkPath === currentPath) {
        link.classList.add("is-active");
        link.setAttribute("aria-current", "page");
      }
    });
  }
  setActiveNavLink();
})();
