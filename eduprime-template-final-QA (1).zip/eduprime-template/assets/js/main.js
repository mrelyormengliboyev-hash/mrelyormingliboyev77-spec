/* ==========================================================================
   EduPrime — Main
   Entry point. navigation.js self-initializes; this file wires up the
   optional components.js behaviors that only some pages contain, and
   handles small page-wide details like the dynamic footer year.
   ========================================================================== */

document.addEventListener("DOMContentLoaded", function () {
  if (window.EduPrimeComponents) {
    window.EduPrimeComponents.initAccordion();
    window.EduPrimeComponents.initStatCounters();
    window.EduPrimeComponents.initBackToTop();

    // Course & Teacher filters only run on pages that contain them —
    // initFilterGroup() exits immediately if the bar/grid aren't found.
    window.EduPrimeComponents.initFilterGroup({
      filterBarSelector: "#course-filter-bar",
      gridSelector: "#course-grid",
      itemSelector: ".course-card",
      emptySelector: "#course-filter-empty",
      statusSelector: "#course-filter-status",
    });

    window.EduPrimeComponents.initFilterGroup({
      filterBarSelector: "#teacher-filter-bar",
      gridSelector: "#teacher-grid",
      itemSelector: ".teacher-card",
      emptySelector: "#teacher-filter-empty",
      statusSelector: "#teacher-filter-status",
    });

    // Contact form only runs on contact.html — initContactForm() exits
    // immediately if #contact-form isn't found on the current page.
    window.EduPrimeComponents.initContactForm();
  }

  // EDIT: this automatically keeps the footer copyright year current —
  // no need to manually update it.
  const yearEl = document.getElementById("current-year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
});
