/* ==========================================================================
   EduPrime — Components
   Reusable, self-initializing UI behaviors: FAQ accordion, animated
   statistic counters, and the back-to-top button. Each initializer
   checks for its markup before running, so this file is safe to load
   on any page even if a section is absent.
   ========================================================================== */

(function () {
  "use strict";

  const prefersReducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;

  /* -----------------------------------------------------------------
     FAQ Accordion
     ----------------------------------------------------------------- */
  function initAccordion() {
    const accordions = document.querySelectorAll("[data-accordion]");
    accordions.forEach(function (accordion) {
      const items = accordion.querySelectorAll(".accordion-item");

      items.forEach(function (item) {
        const trigger = item.querySelector(".accordion-item__trigger");
        const panel = item.querySelector(".accordion-item__panel");
        if (!trigger || !panel) return;

        trigger.addEventListener("click", function () {
          const isOpen = trigger.getAttribute("aria-expanded") === "true";

          // Close other open items so only one is expanded at a time.
          items.forEach(function (otherItem) {
            const otherTrigger = otherItem.querySelector(".accordion-item__trigger");
            const otherPanel = otherItem.querySelector(".accordion-item__panel");
            if (otherTrigger && otherTrigger !== trigger) {
              otherTrigger.setAttribute("aria-expanded", "false");
              if (otherPanel) otherPanel.style.maxHeight = null;
            }
          });

          trigger.setAttribute("aria-expanded", String(!isOpen));
          panel.style.maxHeight = isOpen ? null : panel.scrollHeight + "px";
        });
      });
    });
  }

  /* -----------------------------------------------------------------
     Statistic count-up animation
     Respects prefers-reduced-motion by displaying the final value
     immediately instead of animating.
     ----------------------------------------------------------------- */
  function animateCount(el) {
    const target = parseInt(el.getAttribute("data-count-to"), 10) || 0;
    const suffix = el.getAttribute("data-suffix") || "";

    if (prefersReducedMotion) {
      el.textContent = target.toLocaleString() + suffix;
      return;
    }

    const duration = 1400;
    const startTime = performance.now();

    function tick(now) {
      const progress = Math.min((now - startTime) / duration, 1);
      // Ease-out for a natural deceleration toward the final number.
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(eased * target);
      el.textContent = current.toLocaleString() + suffix;
      if (progress < 1) {
        window.requestAnimationFrame(tick);
      }
    }
    window.requestAnimationFrame(tick);
  }

  function initStatCounters() {
    const counters = document.querySelectorAll("[data-count-to]");
    if (!counters.length) return;

    if (!("IntersectionObserver" in window)) {
      counters.forEach(animateCount);
      return;
    }

    const observer = new IntersectionObserver(
      function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            animateCount(entry.target);
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.4 }
    );

    counters.forEach(function (counter) {
      observer.observe(counter);
    });
  }

  /* -----------------------------------------------------------------
     Back to top button
     ----------------------------------------------------------------- */
  function initBackToTop() {
    const button = document.querySelector(".back-to-top");
    if (!button) return;

    window.addEventListener("scroll", function () {
      if (window.scrollY > 600) {
        button.classList.add("is-visible");
      } else {
        button.classList.remove("is-visible");
      }
    });

    button.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: prefersReducedMotion ? "auto" : "smooth" });
    });
  }

  /* -----------------------------------------------------------------
     Generic filter group (used by Courses and Teachers category
     filters). Cards are matched against a button's data-filter value
     using each card's data-category attribute. Safe to call multiple
     times on the same page with different selectors; does nothing if
     the bar or grid isn't present on the current page.
     ----------------------------------------------------------------- */
  function initFilterGroup(options) {
    const bar = document.querySelector(options.filterBarSelector);
    const grid = document.querySelector(options.gridSelector);
    if (!bar || !grid) return;

    const buttons = Array.prototype.slice.call(bar.querySelectorAll(".filter-btn"));
    const items = Array.prototype.slice.call(grid.querySelectorAll(options.itemSelector));
    const empty = options.emptySelector ? document.querySelector(options.emptySelector) : null;
    const status = options.statusSelector ? document.querySelector(options.statusSelector) : null;

    function applyFilter(category) {
      let visibleCount = 0;

      items.forEach(function (item) {
        const matches = category === "all" || item.getAttribute("data-category") === category;
        item.classList.toggle("is-hidden", !matches);
        if (matches) visibleCount += 1;
      });

      if (empty) {
        empty.hidden = visibleCount !== 0;
      }

      if (status) {
        status.textContent =
          "Showing " + visibleCount + " of " + items.length +
          (items.length === 1 ? " result" : " results");
      }
    }

    buttons.forEach(function (button) {
      button.addEventListener("click", function () {
        buttons.forEach(function (btn) {
          btn.setAttribute("aria-pressed", "false");
        });
        button.setAttribute("aria-pressed", "true");
        applyFilter(button.getAttribute("data-filter"));
      });
    });

    if (empty) {
      const resetButton = empty.querySelector("[data-filter-reset]");
      if (resetButton) {
        resetButton.addEventListener("click", function () {
          const allButton = bar.querySelector('[data-filter="all"]');
          if (allButton) allButton.click();
        });
      }
    }

    // Start from the "All" state on page load.
    applyFilter("all");
  }

  /* -----------------------------------------------------------------
     Contact form validation (frontend-only)
     No backend is included by design — see README.md /
     CUSTOMIZATION-GUIDE.md for how to connect this to a real email or
     form-handling service. This only validates fields and shows a
     polished demo success state.
     ----------------------------------------------------------------- */
  function initContactForm() {
    const form = document.getElementById("contact-form");
    if (!form) return;

    const successPanel = document.getElementById("contact-form-success");
    const statusRegion = document.getElementById("contact-form-status");
    const resetButton = document.getElementById("contact-form-reset");

    const validators = {
      name: function (value) {
        return value.trim().length >= 2;
      },
      email: function (value) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
      },
      phone: function (value) {
        // Optional field — empty is valid; if filled, do a loose check.
        return value.trim() === "" || /^[0-9+\-\s()]{7,20}$/.test(value.trim());
      },
      subject: function (value) {
        return value.trim().length >= 2;
      },
      message: function (value) {
        return value.trim().length >= 10;
      },
    };

    function setFieldError(field, hasError) {
      const wrapper = field.closest(".form-field");
      if (wrapper) wrapper.classList.toggle("has-error", hasError);
      field.setAttribute("aria-invalid", hasError ? "true" : "false");
    }

    function validateField(field) {
      const validator = validators[field.name];
      if (!validator) return true;
      const isValid = validator(field.value);
      setFieldError(field, !isValid);
      return isValid;
    }

    // Give feedback as soon as a field loses focus, not only on submit.
    Array.prototype.forEach.call(form.elements, function (field) {
      if (!validators[field.name]) return;
      field.addEventListener("blur", function () {
        validateField(field);
      });
    });

    form.addEventListener("submit", function (event) {
      event.preventDefault();

      let firstInvalidField = null;

      Array.prototype.forEach.call(form.elements, function (field) {
        if (!validators[field.name]) return;
        const isValid = validateField(field);
        if (!isValid && !firstInvalidField) {
          firstInvalidField = field;
        }
      });

      if (firstInvalidField) {
        if (statusRegion) {
          statusRegion.textContent = "Please correct the highlighted fields and try again.";
        }
        firstInvalidField.focus();
        return;
      }

      // All fields valid — show the demo success state. Nothing is sent
      // anywhere; wire this up to your own backend/email service when ready.
      form.hidden = true;
      if (successPanel) {
        successPanel.hidden = false;
        successPanel.focus();
      }
      if (statusRegion) {
        statusRegion.textContent =
          "Demo submission received. This is a template — no message was actually sent.";
      }
    });

    if (resetButton) {
      resetButton.addEventListener("click", function () {
        form.reset();
        Array.prototype.forEach.call(form.elements, function (field) {
          if (!validators[field.name]) return;
          setFieldError(field, false);
        });
        if (successPanel) successPanel.hidden = true;
        form.hidden = false;
        const firstField = form.querySelector("input, textarea");
        if (firstField) firstField.focus();
      });
    }
  }

  window.EduPrimeComponents = {
    initAccordion: initAccordion,
    initStatCounters: initStatCounters,
    initBackToTop: initBackToTop,
    initFilterGroup: initFilterGroup,
    initContactForm: initContactForm,
  };
})();
